<template>
    <div id="Login">
        <div class="one">
            <img src="../assets/imgs/bgImg.png">
        </div>
        <div class="two space">
            <div>
                <center><h1>人才来源</h1>
                <p>乐鱼网兼职技术人员来自各大互联网公司，普遍具有多年工作经验，平台严格把控人才入口，确保工作质量和效率。</p>
                </center>
            </div><hr/>
            <div class="imgs">
                <div>
                    <img src="../assets/imgs/i_baidu.jpg">
                    <img src="../assets/imgs/i_alibaba.jpg">
                    <img src="../assets/imgs/i_tengxun.jpg">
                    <img src="../assets/imgs/i_wangyi.jpg">
                    <img src="../assets/imgs/i_jingdong.jpg">
                </div>
                <div class="img_btom">
                    <img src="../assets/imgs/i_sina.jpg">
                    <img src="../assets/imgs/i_360.jpg">
                    <img src="../assets/imgs/i_souhu.jpg">
                    <img src="../assets/imgs/i_xiaomi.jpg">
                    <img src="../assets/imgs/i_suning.jpg">
                </div>
            </div>
            <div class="two_btn">
                <center> 
                    <button class="btn btn-primary">
                        <router-link to="/part">浏览技术人才</router-link>
                    </button>
                    <button class="btn btn-success">
                        <router-link to="/login" >发布招聘需求</router-link>                       
                    </button>
                </center>
            </div>
        </div>
        <div class="three">
            <div>
                <center><h1>快速到班</h1>
                <p>简化预约流程，为有需求的团队节省预约时间，极大限度的满足快速到班的需求，兼职时间灵活，双方可自由约定。</p>
                </center>
            </div><hr/>
            <div class="three_img">
                <div>
                    <div><img src="../assets/imgs/hand.jpg" alt=""></div>
                    <p>急速沟通</p>
                </div>
                <div>
                    <div><img src="../assets/imgs/door.jpg" alt=""></div>
                    <p>公司坐班</p>
                </div>
            </div>
        </div>
        <div class="four">
            <div>
                <center><h1>担保交易</h1>
                <p>薪酬先支付到乐鱼网，确认完工后，再支付给人才。按需支付，未工作时间无忧退款。如发生纠纷，乐鱼网介入调查仲裁保证服务满意度。</p>
                </center>
            </div><hr/>
            <div>
                <img src="../assets/imgs/four.jpg">
            </div>
        </div>
        <div></div>
        <div></div>
        <div class="footer">
            <div class="f_top">
                <div>
                    <h5>新手指南</h5>
                    <ul> 
                        <li><a href="#">规则中心</a></li>
                        <li><a href="#">雇主入门</a></li>
                        <li><a href="#">注册新用户</a></li>
                        <li><a href="#">技术兼职入门</a></li>
                    </ul>
                </div>
                <div>
                    <h5>我是雇主</h5>
                    <ul>
                        <li><a href="#">发布招聘需求</a></li>
                        <li><a href="#">挑选技术兼职</a></li>
                    </ul>
                </div>
                <div>
                    <h5>我是技术兼职</h5>
                    <ul>  
                        <li><a href="#">发布简历</a></li>
                        <li><a href="#">投递职位</a></li>
                    </ul>
                </div>
                <div>
                    <h5>交易保障</h5>
                    <ul>
                        <li><a href="#">雇主保障</a></li>
                        <li><a href="#">众包平台</a></li>
                        <li><a href="#">乐鱼担保交易</a></li>
                    </ul>
                </div>
            </div>
            <div class="f_bottom">
                <ul>
                    <li><a href="#">关于我们</a></li>
                    <li><a href="#">企业文化</a></li>
                    <li><a href="#">联系方式</a></li>
                    <li><a href="#">使用协议</a></li>
                    <li><a href="#">网站地图</a></li>
                    <li><a href="#">友情链接</a></li>
                    <li><a href="#">网站留言</a></li>
                </ul>
                <br>
                <center>
                    <p>友情链接： <a href="#">山东钢结构</a> &nbsp;<a href="#">钢结构厂房</a> &nbsp;<a href="#">钢结构</a></p>
                    <p>&copy; 乐鱼网 All Right Reserved 鲁ICP备 15008460号</p>
                </center>
            </div>
        </div>
    </div>
</template>
<script>

export default {
    name:'Login'
}
</script>
<style scoped>
.one img{
     margin-top: -4px;
     width: 100%;
}   
.space{
    margin: 70px 300px
}
.imgs{
    margin-left: 30px;
}
.two img{
    margin: 20px 40px;
    text-align: center;
}
.img_btom img{
    margin: 20px 49px ;
}
.two_btn{
    margin-top: 50px;
}
.two_btn a{
    color: #ffe;
}
.two_btn button:first-child{
    margin-right: 120px;
}
.three{
    background: #f1f5f7;
    padding: 70px 300px 200px;
}
.three_img{
    margin: 75px 155px;
}
.three_img > div{
    float: left;
    margin-left: 175px;
}
.four{
     padding: 70px 200px;
}
.four img{
    margin-left: 110px;
}
.f_top{
    background: #606878;
    padding: 70px 0 70px 320px;
}
.f_top>div{
   display: inline-block;
   width: 280px;
}
.f_top>div>ul>li{
   width: 100%;
   margin-top: 2px;
}
.f_top h5,.f_top a{
    color: #dedede;
}
.f_bottom{
    padding: 30px 533px;
    color: #999;
    font-size: 14px;
}
.f_bottom li{
    margin-right: 18px;
}
</style>
