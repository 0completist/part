<template>
  <div id="navbar">
    <div class="left">
      <ul>
        <li v-for="(item,index) in navbarLeft" :key="index">
          <router-link :to='item.href'>{{ item.page }}</router-link>
        </li>
      </ul>
    </div>
    <div class="right">
      <ul>
        <li  data-toggle="modal" data-target="#myRegister">
          <router-link to="/register">注册</router-link>
        </li>
         <li  data-toggle="modal" data-target="#myLogin">
          <router-link to="/login" >登录</router-link>
        </li>
      </ul>
    </div>
    <!-- 登录模态框 -->
    <div class="modal fade" id="myLogin" tabindex="-1" >
      <div class="login-page">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4>会员登录</h4>
            </div>
            <div class="modal-body">
              <div class="main-content">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" >
                  <li  class="active lable-page"><a href="#home" aria-controls="home" data-toggle="tab">账号登录</a></li>
                  <li class="lable-page"><a href="#profile" aria-controls="profile" data-toggle="tab">手机动态</a></li>
                  <li class="lable-page"><a href="#messages" aria-controls="messages"  data-toggle="tab">微信扫码</a></li>
                </ul>
                <div class="borderdiv"></div>
                <!-- 标签页内容区 -->
                <div class="tab-content">
                  <div role="tabpanel" class="tab-pane fade in active" id="home" >
                    <form action="" class="account">
                      <input type="text" placeholder="手机号">
                      <input type="password" placeholder="密码">
                      <input type="checkbox">记住密码 <span><a href="#">找回密码</a></span>
                      <br/>
                      <input type="button" class="btn btn-primary" value="登录">
                    </form>
                  </div>
                  <div role="tabpanel" class="tab-pane fade in active" id="profile">
                    <form action="" class="mobile">
                      <input type="text" placeholder="手机号">
                      <input type="text" placeholder="动态码">
                      <input type="button" class="btn-primary" value="立即发送">
                      <input type="button" class="btn btn-primary" value="登录"> 
                    </form>
                  </div>
                  <div role="tabpanel" class="tab-pane fade in active" id="messages">
                    <div id="qr">
                      <canvas id="canvas" width="150" height="150"></canvas>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <span>第三方登录：</span>
              <div class="other-login">
                <img src="../assets/imgs/QQ.png" alt=""><img src="../assets/imgs/weibo.png" alt="">
                <span><a href="#">还没有账号？</a></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 注册模态框 -->
    <div class="modal fade" id="myRegister" tabindex="-1" >  
      <div class="login-page">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4>新用户注册</h4>
            </div>
            <div class="modal-body">
              <form action="" class="account">
                <input type="text" placeholder="手机号">
                <input type="password" placeholder="密码">
                <input type="checkbox"> <span class="service"><a href="#">《乐鱼网服务》</a></span>
                <br/>
                <input type="button" class="btn btn-primary" value="同意协议并注册">
              </form>
            </div>
            <div class="modal-footer">
              <span>第三方登录：</span>
              <div class="other-login">
                <img src="../assets/imgs/QQ.png" alt=""><img src="../assets/imgs/weibo.png" alt="">
                <span><a href="#">有账号？登录</a></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
let QRCode = require('qrcode');
export default {
  name: 'Navbar',
  data () {
    return {
      navbarLeft:[
        {page:'乐鱼网',href:'/'},      
        {page:'技术兼职',href:'/part'},      
        {page:'招聘需求',href:'/invite'}   
      ]
    }
  },
  methods: {
    
  },
  mounted(){
    let url = 'https://weixin.qq.com';
    QRCode.toCanvas(document.querySelector('#canvas'), url,{
      margin:3,    
      width:10,
      color:{
        dark:'#000',
        light:'#fff'
      }
    }, function (error) {
      if (error) console.error(error)
      console.log('success!');
    })
  }
}
</script>


<style scoped>
#navbar{
  width: 100%;height: 44px;
  background:linear-gradient(top,#fff,#eee);
}
ul{
  margin-left: 100px;
}
.left li{
  margin: 12px 10px;
  font-weight: bold;
  font-size: 14px;
  border-right: 1px solid #ddd;
  padding-right: 20px;
}
.left li:first-child{
  font-size: 18px;
  font-weight: 300;
  margin-top: 9px;
}
li:last-child{
  border-right: 0;
}
.right{
  margin-right: 100px;
}
.right li{
  float: right;
  margin: 10px;
  color: #999;
  font-size: 14px;
  padding:2px 15px 0 0;
}
.login-page{
  width: 350px;
  position: absolute;
  left: 450px;
  top: 50px;
}
.main-content .login-page>a:hover{
  background: #999;
  border: 1px solid #000;
}
.main-content{
  height: 275px;
}
.main-content>ul{
  margin-left: 25px;
  border: 0; 
}
.borderdiv{
  border-bottom: 1px solid #eee;
  position: relative;
  top: 5px;
}
.lable-page>a {
    padding: 8px;
    line-height: 20px;
    background: #eeeeee50;
    margin-right: 10px;
    border-radius: 4px 4px 0 0;
}
form{
  margin: 15px 0 0 24px;
  font-size: 14px;
}
input:nth-child(1),input:nth-child(2n),input:nth-child(5){
  width: 89%;
  border: 1px solid #ddd;
  border-radius: 8px;
  margin: 20px 20px 0 0;
  color: rgb(1, 0, 0);
  padding: 5px;
}
input:nth-child(3){
  margin: 20px 3px 0;
}
span{
  float: right;
  margin: 13px 35px 0;
}
span a{
  color: #00c;
}
.modal-footer{
  position: relative;
}
.modal-footer span{
  font-size: 14px;
  font-weight: 500;
  position: absolute;
  left: 0px;
  top: 7px;
}
.other-login img:first-child{
  position: relative;
  left: -160px;
  top:-2px;
}
.other-login img:nth-child(2){
  position: relative;
  left: -160px;
  top:-2px;
}
.other-login span a {
  margin-left: 184px;
}
.mobile input:nth-child(2){
  width: 50%;
}
.mobile input:nth-child(3){
  border: 1px solid #ddd;
  border-radius: 8px;
  margin: 20px 20px 0 0;
  color: rgb(1, 0, 0);
  padding: 5px;
  opacity: 0.9;
}
#canvas{
  border: 1px solid rgb(71, 65, 65);
  position: relative;
  top: 60px; left: 85px;
  width: 150px;
  height: 150px;
}
.service a{
  margin-left:-216px;
  font-size: 13px;
}
</style>
