<template>
    <div id="part">
        <div class="all">
            <div class="top">
                <div class="t_top">
                    <span>工作地点</span><span class="glyphicon glyphicon-triangle-bottom"></span>        
                    <input type="text" placeholder="请输入关键字搜索">
                </div>
                <div class="t_bottom">
                    <table class="table">
                        <tr>
                            <td v-for="(item,index) in firstTrData" :key="index">{{ item.name }}</td>
                        </tr>
                         <tr>
                            <td v-for="(item,index) in lastTrData" :key="index">{{item.name}}</td>
                        </tr>
                    </table>
                    <div class="two_btn">
                        <button><router-link to="/part">浏览技术人才</router-link></button>
                        <button><router-link to="/login" >发布招聘需求</router-link></button>
                    </div>
                </div>
            </div>
            <div class="main">
                <div class="one">
                    <ul>
                        <li>
                            <img src="../assets/imgs/head.png">
                            <tab>平面设计师</tab>
                        </li>
                        <li>
                            <h5>互联网公司  平面设计  3年工作经验</h5>
                            <p>技术经验：能独立完成店铺的首页、详情、直通车、钻展、主图的设计和产品优化。以及活动期间店铺的整体设计。 ppt设计制作，易企秀H5，秀米微信图文排版。</p>
                            <p>项目经验：1、负责公司电商平台装修、首页和宝贝详情页设计制作及活动海报、展位图的制作。 2、产品的图片处理、编辑、美化、宝贝描述、配图文字的排版设计等工作； 3、负责平台整体形象设计更新，商品描述美化，配合公司做好</p>                    
                        </li>
                        <li>
                            <msg>薪酬：120 元 / 8小时</msg>
                            <msg>联系电话：153654800770 </msg>
                            <msg> 
                                可兼职时间：<br>
                                工作日下班后,周六,周日
                            </msg>
                            <msg>
                                可兼职地点：山东
                            </msg>     
                            <button class="btn btn-success focus">关注</button><button class="btn btn-danger">立即预约</button>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>
<script>

export default {
    name:'Part',
    data() {
        return {
            firstTrData:[
                {name:'雇主保障：'},{name:'全部'},{name:'不满意退款'},{name:'保证完成'},{name:'保证原创'},
                {name:'保证维护'},{name:'提供源码'},{name:'保证推广效果'},{name:''},{name:''},{name:''}
            ],
            lastTrData:[
                {name:'兼职角色：'},{name:'全部'},{name:'移动开发'},{name:'后端开发'},{name:'前端开发'},{name:'维护人员'},
                {name:'视觉设计'},{name:'交互设计'},{name:'产品经理'},{name:'测试人员'},{name:'产品设计师'},
            ]
        }
    },
}
</script>
<style scoped>
#part{
    background: #ebeced;  
    opacity: 0.6;
}
.all{
    width: 80%;
    margin: 0 auto;
    padding: 100px;
    font-size: 14px;
}
.top{
    padding: 40px 20px;
    border-radius: 5px;
    background: #fff;
}
.t_top span{
    font-size: 20px;
    margin-left: 5px;
}
.t_top{
    border-bottom: 1px solid #eee;
    padding-bottom: 25px;
}
.t_top input{
    width: 550px;
    border: 1px solid #999;
    border-radius: 20px;
    font-size: 12px;
    padding: 5px 20px;
    float: right;
    margin-right: 10px;
}
.two_btn button{
    height: 30px;
    background: #28a745;
    border-radius: 5px;
    padding: 5px 15px;
    margin: 5px 0 0 180px;
}
.two_btn button:first-child{
    background: #227cdc;
}
.two_btn button a{
    color: #fff;
    font-size: 14px;
    margin-top: -8px;
}
.main{
    margin: 50px 0;
    padding: 30px 0 0 30px;
    height: 300px;
    background: #fff;
    border-radius: 5px;
}
.one li{
    float: left;
    margin-right: 10px;
}
.one li:first-child{
    width: 150px;
}
.one li:nth-child(2){
    width: 600px;
    padding-right: 30px;
    border-right: 1px solid #eee;
    margin-top: 10px;
}
.one li:nth-child(3){
    width: 250px;
    padding-left: 30px;
}
tab{
    color: #fff;
    width: 50px;height: 50px;
    background: #f00;
    padding: 5px;margin-left: 25px;
    border-radius: 5px;
}
.one h5{
    margin-bottom: 25px;
}
msg:first-child{
    margin-top: 5px;
}
msg{
    display: block;
    margin-top: 5px;
}
li button{
    margin-top: 12px;
}
.focus{
    margin-right: 15px;
}
</style>
