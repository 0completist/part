<template>
  <div id="app">
    <Navbar></Navbar>
     <!-- <div class="btn-group" role="group" aria-label="...">  
      <button type="button" class="btn btn-default">Left</button>  
      <button type="button" class="btn btn-default">Middle</button>  
      <button type="button" class="btn btn-default">Right</button>   -->
    <!-- </div>  -->
    <router-view/>
  </div>
</template>

<script>

import Navbar from '@/components/Navbar'
export default {
  name: 'App',
  components:{
    Navbar
  }
}
</script>

<style>
*{
  margin: 0; padding: 0;
}
body{
  margin-top:-16px;
}
li{
  list-style: none;
  float: left;
}
a{
  text-decoration: none;
  color: #999;
}
a:hover{
  color: #000;
  text-decoration: none;
  cursor:pointer;
}
</style>
