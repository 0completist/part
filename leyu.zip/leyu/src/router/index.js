import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/navbar',
      name: 'Navbar',
      component: resolve => require(['@/components/Navbar'],resolve)
    },{
      path:'/',
      name:'leyu',
      component: resolve => require(['@/components/Leyu'],resolve)
    },{
      path:'/part',
      name:'part',
      component: resolve => require(['@/components/Part'],resolve)
    }
  ]
})
